export interface Token {
	token: string;
	expireSeconds: number;
	sessionId:string; 
}