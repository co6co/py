export interface SelectItem {
  id: number
  name: string
}
