<template>
	<div class="container">
		<div class="plugins-tips">
			如果该框架对你有帮助，那就请作者喝杯饮料吧！<el-icon><ColdDrink /></el-icon> 加微信号linxin_20探讨问题。
		</div>
		<div>
			<img src="https://lin-xin.gitee.io/images/weixin.jpg" />
		</div>
	</div>
</template>

<script setup lang="ts" name="donate"></script>

<style></style>
