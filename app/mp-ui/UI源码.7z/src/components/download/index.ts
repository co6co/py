
import download from './src/download.vue' 
export {download}  
