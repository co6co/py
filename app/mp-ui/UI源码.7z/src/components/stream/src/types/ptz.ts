export type ptz_name="up"|"down"|"right"|"left"|"zoomin"|"zoomout"|"center";
export type ptz_type="starting"|"stop";
export type ptz_stop_event="uped"|"downed"|"righted"|"lefted"|"zoomined"|"zoomouted"|"centered";
export type ptz_start_event="uping"|"downing"|"righting"|"lefting"|"zoomining"|"zoomouting"|"centering";