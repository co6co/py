
import detailsInfo from './src/detailsInfo.vue' 
export {detailsInfo}  
