import  editUser from './src/editUser.vue'
import   * as model from './src/model'
export {editUser ,model}  