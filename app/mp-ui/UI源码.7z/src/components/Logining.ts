import {
	defineComponent,
	createElementVNode,
	openBlock,
	createElementBlock,
	watchEffect,
} from 'vue';
import { ElLoading, ElMessage } from 'element-plus';
/* 全局请求 loading */
let loadingInstance: ReturnType<typeof ElLoading.service>;
const start = () => {
	loadingInstance = ElLoading.service({
		fullscreen: true,
		lock: true,
		 text: 'Loading',
		background: 'rgba(0, 0, 0, 0.2)', 
	});
};
const close = () => {
	loadingInstance.close();
};

let needLoadingRequestCount = 0;
export const showLoading = () => {
	if (needLoadingRequestCount === 0) {
		start();
	}
	needLoadingRequestCount++;
};
export const closeLoading = () => {
	if (needLoadingRequestCount <= 0) return;
	needLoadingRequestCount--;
	if (needLoadingRequestCount === 0) {
		close();
	}
};
//全屏loging 
export const Logining = defineComponent({
	name: 'Logining',
	props: {
		logining: {
			type: Boolean,
			default: true,
		},
	}, 
	setup(__props) {
		const _loading = ElLoading.service({ fullscreen: true });
		watchEffect(() => {
			if (!__props.logining) _loading.close();
			_loading.visible.value = true;
		});
	},
});
