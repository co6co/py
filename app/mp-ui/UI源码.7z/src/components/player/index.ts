import Player from './src/Player.vue'
import * as types from './src/types'
import imgVideo from './src/imgVideo.vue' 


export {Player,imgVideo, types}