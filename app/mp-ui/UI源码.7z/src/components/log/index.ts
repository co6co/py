
import log from './src/log.vue' 
export {log}  
