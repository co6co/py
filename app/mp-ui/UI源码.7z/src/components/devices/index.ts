
import talker from './src/talker.vue' 
import deviceNav from './src/deviceNav.vue'
import * as types from "./src/types";
export {talker,deviceNav,types}  
